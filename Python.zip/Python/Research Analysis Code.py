import json
import csv 
import time
import serial
#serialcom = serial.Serial('COM11',9600)


from websocket import create_connection
from threading import Thread
ws = create_connection("wss://localhost:6868")
command =""
confLevel=0.0


def check_connect():
    ws.send(json.dumps({
        "id":1,
        "jsonrpc":"2.0",
        "method":"getCortexInfo"
    }))
    result = ws.recv()
    result = json.loads(result)
    return result


def close_connection():
    ws.close()


def getUserLogin():
    ws.send(json.dumps({
        "id":1,
        "jsonrpc":"2.0",
        "method":"getUserLogin"
    }))
    result = ws.recv()
    result = json.loads(result)
    return result



def accessright(clientId, clientSecret):
    ws.send(json.dumps({
        "id": 1,
        "jsonrpc": "2.0",
        "method": "requestAccess",
        "params": {
            "clientId": clientId,
            "clientSecret": clientSecret
        }
    }))
    result = ws.recv()
    result = json.loads(result)
    return result


def authorizeUser(clientId, clientSecret):
    ws.send(json.dumps({
        "id": 1,
        "jsonrpc": "2.0",
        "method": "authorize",
        "params": {
            "clientId": clientId,
            "clientSecret": clientSecret
        }
    }))
    result = ws.recv()
    result = json.loads(result)
    return result



def queryHeadset():
    ws.send(json.dumps({
        "id": 1,
        "jsonrpc": "2.0",
        "method": "queryHeadsets"
    }))
    result = ws.recv()
    result = json.loads(result)
    return result


def openSession(cortexToken,headset):
    ws.send(json.dumps({
        "id": 1,
        "jsonrpc": "2.0",
        "method": "createSession",
        "params": {
            "cortexToken": cortexToken,
            "headset": headset,
            "status": "open"
        }
    }))
    result = ws.recv()
    result = json.loads(result)
    return result


def subscribeData(cortexToken,sessionId, streams):
    global command
    global confLevel
    ws.send(json.dumps({
        "id": 1,
        "jsonrpc": "2.0",
        "method": "subscribe",
        "params": {
            "cortexToken": cortexToken,
           "session": sessionId,
            "streams": ["com"]
        }
    }))
    
    ws.send(json.dumps({
        "id": 1,
        "jsonrpc": "2.0",
        "method": "subscribe",
        "params": {
            "cortexToken": cortexToken,
            "session": sessionId,
            "streams": ["pow"]
        }
    }))
    flag = 0 
    temp1='s'
    temp='neutral'
    while True:
        result = ws.recv()
        result = json.loads(result)
        if 'com' in result:
            if flag == 0:
                flag =1
                continue
            command = result['com'][0]
            confLevel = result['com'][1]
            #print(result)
            i='s'
        
    
            if command=='neutral':
                i='s'
                temp=str(command)
                #serialcom.write(i.encode())
                #print(command)
                #print(confLevel)
            elif command=='push' and confLevel >= 0.50: 
                i='f'
                temp=str(command)
            
                #print(serialcom.readline().decode('ascii'))
            
            elif command=='pull'and confLevel >= 0.50:
                i='b'
            elif command=='left' and confLevel >= 0.60: 
                i='l'
                temp=str(command)
            
            # print(serialcom.readline().decode('ascii'))
            elif command=='right'and confLevel >= 0.60:
                i='r'
                temp=str(command)
            
            #print(serialcom.readline().decode('ascii'))
         
         
      
            
    
       # print(command)
        
        

        
        if temp1!=temp:
            if  'pow' in result:
                with open('powDataCommand.csv', mode='a+') as met_data:
                    data_writer = csv.writer(met_data, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
                    data_writer.writerow(result['pow'])
                    print(command)
                    temp1=str(command)
           # serialcom.write(i.encode())

            
            
            

            
        
        
        
        #print("l")
        #print(serialcom.readline().decode('ascii'))
        
        


def mainfunc():
   # global command
   # global confLevel
    clientId = 'MuBZ0RZF64nX5PGmMcvzKYnwFVf9xy2iQedZ0x1d'
    clientSecret = 'Od9O2ONXSV6j2rVISERc2X0MtO4NiGy2wrqbUNRjFumIJRiFQyqvxXXcn08prFOn6AQQPcKmEufBuzAG7CCwLQb25BXxatD4UFeTAGifOiITcovcz51rf31i8AHpW7Wh'
    cortexToken = ''
    headsetId = ''
    sessionId = ''
    check_response = check_connect()
    print("BCI App version " + check_response['result']['version'])

    userInfo =getUserLogin()
    print("Connected user = " + userInfo['result'][0]['username'])


    accessRes = accessright(clientId,clientSecret)
    print(accessRes['result']['message'])

    authRes = authorizeUser(clientId,clientSecret)
    cortexToken = authRes['result']['cortexToken']
    print('CortexToken = ' + cortexToken)

    headsetRes = queryHeadset()
    if not headsetRes['result']:
        print('no headset is connected')
    else:
        headsetId = headsetRes['result'][0]['id']
        print('Connected headset = '+ headsetId)


    sessionRes = openSession(cortexToken,headsetId)
    sessionId = sessionRes['result']['id']
    print('Session id = ' + sessionId)
    subscribeData(cortexToken,sessionId,"com")
   


mainfunc()

#serial.close() 
